# Compiler Design – Experiment Outputs

This repository section contains sample output transcripts and terminal-style illustrative screenshots for 40 Compiler Design laboratory experiments.

**Important:** The original C/LEX/FLEX source programs were not supplied. Therefore, these files are clearly labelled illustrative sample outputs and are not verified captures from compiled programs. Run the corresponding source programs and compare/replace the samples before submitting them as actual lab evidence.

## Folder structure
Each `Experiment-XX/` folder contains:
- `output.txt` – sample terminal transcript
- `screenshot.png` – terminal-style illustrative image of the same transcript

No source code files are included.
